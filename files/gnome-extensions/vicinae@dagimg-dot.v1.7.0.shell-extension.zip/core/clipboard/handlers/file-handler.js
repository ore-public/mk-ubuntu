import St from "gi://St";
import {
  decodeClipboardBytes,
  isFileUri,
  parseFileUris,
  toUriListFormat
} from "../../../utils/clipboard-utils.js";

const MIME_TYPE = "text/uri-list";

class FileHandler {
  mimeTypes = [MIME_TYPE];
  priority = 1;

  matchesMimeTypes(types) {
    return types.includes(MIME_TYPE);
  }

  matchesContent(content) {
    return isFileUri(content);
  }

  capture(clipboard, onResult, _context) {
    clipboard.get_content(
      St.ClipboardType.CLIPBOARD,
      MIME_TYPE,
      (_, content) => {
        if (!content) return;
        const data = decodeClipboardBytes(content);
        if (data && data.length > 0) {
          const text = new TextDecoder().decode(data).trim();
          if (text) onResult(text);
        }
      }
    );
  }

  set(clipboard, content) {
    const uris = parseFileUris(content);
    const uriListBytes = toUriListFormat(uris);
    if (uriListBytes.length === 0) return false;

    clipboard.set_content(
      St.ClipboardType.CLIPBOARD,
      MIME_TYPE,
      uriListBytes
    );
    clipboard.set_content(
      St.ClipboardType.PRIMARY,
      MIME_TYPE,
      uriListBytes
    );
    return true;
  }

  getMimeType() {
    return MIME_TYPE;
  }

  toSignalPayload(event, _context) {
    if (!event.content) return null;
    return {
      content: new TextEncoder().encode(event.content),
      mimeType: MIME_TYPE
    };
  }
}

export {
  FileHandler
};
