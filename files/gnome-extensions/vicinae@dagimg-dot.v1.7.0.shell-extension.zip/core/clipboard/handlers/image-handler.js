import St from "gi://St";
import {
  bufferLikeToUint8Array,
  decodeClipboardBytes
} from "../../../utils/clipboard-utils.js";

class ImageHandler {
  mimeTypes = [
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp"
  ];
  priority = 2;

  requestedMimeType = "image/png";

  matchesMimeTypes(types) {
    for (const supported of this.mimeTypes) {
      if (types.includes(supported)) {
        this.requestedMimeType = supported;
        return true;
      }
    }
    return false;
  }

  matchesContent(content) {
    return content.startsWith("[BINARY_IMAGE:");
  }

  capture(clipboard, onResult, context) {
    if (!context) return;

    clipboard.get_content(
      St.ClipboardType.CLIPBOARD,
      this.requestedMimeType,
      (_, rawContent) => {
        if (!rawContent) return;

        const data = decodeClipboardBytes(rawContent);
        if (!data || data.length === 0) return;

        const marker = `[BINARY_IMAGE:${this.requestedMimeType}:${data.length}]`;
        context.storeBinaryData(marker, data, this.requestedMimeType);
        onResult(marker);
      }
    );
  }

  set(_clipboard, _content) {
    return false;
  }

  getMimeType(content, source) {
    if (source === "image" && content.startsWith("[BINARY_IMAGE:")) {
      const match = content.match(/^\[BINARY_IMAGE:([^:]+):/);
      return match ? match[1] : "image/png";
    }
    if (content.startsWith("data:image/")) {
      const match = content.match(/^data:(image\/[^;]+);/);
      return match ? match[1] : "image/png";
    }
    return "image/png";
  }

  toSignalPayload(event, context) {
    if (!event.content.startsWith("[BINARY_IMAGE:")) return null;

    const binaryInfo = context.getBinaryData(event.content);
    if (!binaryInfo) return null;

    return {
      content: bufferLikeToUint8Array(binaryInfo.data),
      mimeType: binaryInfo.mimeType
    };
  }
}

export {
  ImageHandler
};
