
class BinaryDataStore {
  store = /* @__PURE__ */ new Map();

  has(marker) {
    return this.store.has(marker);
  }

  get(marker) {
    const entry = this.store.get(marker);
    return entry || null;
  }

  set(marker, data, mimeType) {
    this.store.set(marker, { data, mimeType });
  }

  delete(marker) {
    this.store.delete(marker);
  }

  clear() {
    this.store.clear();
  }

  get size() {
    return this.store.size;
  }
}

export {
  BinaryDataStore
};
