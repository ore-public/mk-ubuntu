import Clutter from "gi://Clutter";
import { logger } from "../../utils/logger.js";
import { SignalRegistry } from "../../utils/signal-registry.js";


class ClickHandler {

  constructor(windowManager, onClickOutside) {
    this.windowManager = windowManager;
    this.onClickOutside = onClickOutside;
  }
  signals = new SignalRegistry();

  enable() {
    try {
      const buttonPressHandler = global.stage.connect(
        "captured-event",
        (_stage, event) => {
          if (event.type() === Clutter.EventType.BUTTON_PRESS) {
            this.handleClick();
          }
          return Clutter.EVENT_PROPAGATE;
        }
      );
      this.signals.add(() => global.stage.disconnect(buttonPressHandler));
      logger.info("ClickHandler: Click tracking enabled");
    } catch (error) {
      logger.error("ClickHandler: Error enabling click tracking", error);
      throw error;
    }
  }

  disable() {
    this.signals.disconnectAll();
    logger.info("ClickHandler: Click tracking disabled");
  }

  handleClick() {
    try {
      const [x, y] = global.get_pointer();
      const windows = global.get_window_actors();
      const window = windows.find((actor) => {
        const win = actor.meta_window;
        if (!win) return false;

        const rect = win.get_frame_rect();
        return x >= rect.x && x <= rect.x + rect.width && y >= rect.y && y <= rect.y + rect.height;
      });

      const clickedWindow = window?.meta_window;

      const isTargetWindow = this.windowManager.isTargetWindow(
        clickedWindow?.get_wm_class() || ""
      );

      if (!clickedWindow || !isTargetWindow) {
        this.onClickOutside();
      }
    } catch (error) {
      logger.error("ClickHandler: Error handling click", error);
    }
  }
}

export {
  ClickHandler
};
