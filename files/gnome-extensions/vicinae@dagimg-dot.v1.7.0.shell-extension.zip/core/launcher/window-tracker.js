import GLib from "gi://GLib";
import { logger } from "../../utils/logger.js";
import { SignalRegistry } from "../../utils/signal-registry.js";


class WindowTracker {

  constructor(appClass, onWindowTracked, onWindowUntracked) {
    this.appClass = appClass;
    this.onWindowTracked = onWindowTracked;
    this.onWindowUntracked = onWindowUntracked;
  }
  trackedWindows = /* @__PURE__ */ new Set();
  signals = new SignalRegistry();
  isDestroying = false;
  idleSourceIds = [];

  enable() {
    try {
      const windowCreatedHandler = global.display.connect(
        "window-created",
        (_display, window) => {
          const idleId = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            this.handleNewWindow(window);
            return GLib.SOURCE_REMOVE;
          });
          this.idleSourceIds.push(idleId);
        }
      );
      this.signals.add(
        () => global.display.disconnect(windowCreatedHandler)
      );

      const windowDestroyHandler = global.window_manager.connect(
        "destroy",
        (_wm, actor) => {
          if (this.isDestroying) return;
          try {
            const metaWindow = actor?.meta_window;
            const windowId = metaWindow?.get_id();
            if (windowId && this.trackedWindows.has(windowId)) {
              this.trackedWindows.delete(windowId);
              this.onWindowUntracked(windowId);
              logger.debug(
                `WindowTracker: Untracking destroyed window ${windowId}`
              );
            }
          } catch {
          }
        }
      );
      this.signals.add(
        () => global.window_manager.disconnect(windowDestroyHandler)
      );

      this.scanExistingWindows();
      logger.info("WindowTracker: Window tracking enabled");
    } catch (error) {
      logger.error(
        "WindowTracker: Error enabling window tracking",
        error
      );
      throw error;
    }
  }

  disable() {
    this.isDestroying = true;
    this.signals.disconnectAll();

    for (const id of this.idleSourceIds) {
      GLib.source_remove(id);
    }
    this.idleSourceIds = [];

    this.trackedWindows.clear();
    this.isDestroying = false;
    logger.info("WindowTracker: Window tracking disabled");
  }

  scanExistingWindows() {
    try {
      const windowActors = global.get_window_actors();
      logger.debug(
        `WindowTracker: Scanning ${windowActors.length} existing windows`
      );

      windowActors.forEach((actor) => {
        if (actor?.meta_window) {
          this.handleNewWindow(actor.meta_window);
        } else {
          logger.debug(
            "WindowTracker: Skipping invalid window actor"
          );
        }
      });
    } catch (error) {
      logger.error(
        "WindowTracker: Error scanning existing windows",
        error
      );
    }
  }

  handleNewWindow(window) {
    if (this.isDestroying) return;

    try {
      const wmClass = window.get_wm_class();
      const title = window.get_title();
      const windowId = window.get_id();

      if (!wmClass || !title || windowId <= 0) {
        return;
      }

      if (wmClass.toLowerCase().includes(this.appClass.toLowerCase())) {
        if (!this.trackedWindows.has(windowId)) {
          this.trackedWindows.add(windowId);
          this.onWindowTracked(windowId);
          this.centerWindow(window);

          logger.debug(
            `WindowTracker: Tracking new window ${windowId} (${wmClass})`
          );
        }
      }
    } catch (error) {
      logger.error("WindowTracker: Error handling new window", {
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : void 0
      });
    }
  }

  getTrackedWindows() {
    return Array.from(this.trackedWindows);
  }

  getTrackedWindowsCount() {
    return this.trackedWindows.size;
  }

  centerWindow(window) {
    if (this.isDestroying) return;

    try {
      const pos = this.getCenterPosition(window);
      if (!pos) return;

      const { x, y } = pos;
      window.move_frame(true, x, y);

      logger.debug(
        `WindowTracker: Centered window ${window.get_id()} at (${Math.round(
          x
        )}, ${Math.round(y)})`
      );
    } catch (error) {
      logger.error("WindowTracker: Error centering window", error);
    }
  }

  getCenterPosition(window) {
    const monitor = window.get_monitor();
    const display = global.display;
    const nMonitors = display.get_n_monitors();

    if (monitor < 0 || monitor >= nMonitors) {
      logger.debug(
        `WindowTracker: Invalid monitor index ${monitor} (n_monitors=${nMonitors}), skipping center`
      );
      return null;
    }

    const monitorGeometry = display.get_monitor_geometry(monitor);

    const frame = window.get_frame_rect();

    const centerX = monitorGeometry.x + (monitorGeometry.width - frame.width) / 2;
    const centerY = monitorGeometry.y + (monitorGeometry.height - frame.height) / 2;

    return { x: centerX, y: centerY };
  }
}

export {
  WindowTracker
};
