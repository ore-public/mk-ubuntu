import GLib from "gi://GLib";
import { logger } from "../../utils/logger.js";
import { VicinaeWindowManager } from "../windows/window-manager.js";
import { ClickHandler } from "./click-handler.js";
import { FocusTracker } from "./focus-tracker.js";
import { WindowTracker } from "./window-tracker.js";



class LauncherManager {
  windowManager;
  windowTracker;
  focusTracker;
  clickHandler;
  config;
  isEnabled = false;
  trackedWindows = /* @__PURE__ */ new Set();
  enableTimeoutId = null;

  constructor(config) {
    this.windowManager = new VicinaeWindowManager(config.appClass);
    this.config = config;
    this.windowTracker = new WindowTracker(
      config.appClass,
      this.handleWindowTracked,
      this.handleWindowUntracked
    );
  }

  async enable() {
    if (this.isEnabled) {
      logger.debug("LauncherManager: Already enabled, skipping");
      return;
    }

    try {
      await this.windowTracker.enable();

      if (this.config.autoCloseOnFocusLoss) {
        this.setupFocusTracking();
        this.setupClickHandling();
      }

      this.isEnabled = true;
      logger.info("LauncherManager: Successfully enabled");
    } catch (error) {
      logger.error("LauncherManager: Error during enable", error);
      this.cleanup();
      throw error;
    }
  }

  handleWindowTracked = (windowId) => {
    this.trackedWindows.add(windowId);
    logger.debug(`LauncherManager: Window ${windowId} is now tracked`);
  };

  handleWindowUntracked = (windowId) => {
    this.trackedWindows.delete(windowId);
    logger.debug(
      `LauncherManager: Window ${windowId} is no longer tracked`
    );
  };

  disable() {
    logger.info("LauncherManager: Disabling");
    this.isEnabled = false;
    this.cleanup();
  }

  setupFocusTracking() {
    this.focusTracker = new FocusTracker(() => this.handleFocusChange());
    this.focusTracker.enable();
  }

  setupClickHandling() {
    this.clickHandler = new ClickHandler(
      this.windowManager,
      () => this.closeTrackedWindows()
    );
    this.clickHandler.enable();
  }

  handleFocusChange() {
    if (!this.isEnabled) return;

    const focusedWindow = global.display.get_focus_window();
    if (!focusedWindow) {
      this.closeTrackedWindows();
      return;
    }

    const focusedWmClass = focusedWindow.get_wm_class()?.toLowerCase() || "";
    if (!focusedWmClass.includes(this.config.appClass.toLowerCase())) {
      this.closeTrackedWindows();
    }
  }

  closeTrackedWindows() {
    if (this.trackedWindows.size === 0) return;

    logger.debug(
      `LauncherManager: Closing ${this.trackedWindows.size} launcher windows due to focus loss`
    );

    const windowsToClose = Array.from(this.trackedWindows);
    this.trackedWindows.clear();

    windowsToClose.forEach((windowId) => {
      try {
        if (this.isValidWindowId(windowId)) {
          this.windowManager.close(windowId);
          this.config.onWindowClosed?.(windowId);
          logger.debug(
            `LauncherManager: Successfully closed window ${windowId}`
          );
        } else {
          logger.debug(
            `LauncherManager: Window ${windowId} no longer valid, skipping close`
          );
        }
      } catch (error) {
        logger.error(
          `LauncherManager: Error closing window ${windowId}`,
          error
        );
      }
    });
  }

  isValidWindowId(windowId) {
    if (!windowId || windowId <= 0) return false;
    try {
      const details = this.windowManager.details(windowId);
      return details && details.id === windowId;
    } catch {
      return false;
    }
  }

  cleanup() {
    try {
      if (this.enableTimeoutId) {
        GLib.source_remove(this.enableTimeoutId);
        this.enableTimeoutId = null;
      }

      this.windowTracker.disable();
      this.focusTracker?.disable();
      this.clickHandler?.disable();
      this.windowManager = null;
      this.trackedWindows.clear();
    } catch (error) {
      logger.error("LauncherManager: Error during cleanup", error);
    }
  }

  updateConfig(newConfig) {
    const oldConfig = { ...this.config };
    this.config = { ...this.config, ...newConfig };

    logger.debug("LauncherManager: Configuration updated", {
      old: oldConfig,
      new: this.config
    });

    if (this.isEnabled) {
      logger.info("LauncherManager: Re-enabling with new configuration");
      this.disable();

      if (this.enableTimeoutId) {
        GLib.source_remove(this.enableTimeoutId);
        this.enableTimeoutId = null;
      }

      this.enableTimeoutId = GLib.timeout_add(
        GLib.PRIORITY_DEFAULT,
        100,
        () => {
          this.enable();
          this.enableTimeoutId = null;
          return false;
        }
      );
    }
  }

  getTrackedWindows() {
    return Array.from(this.trackedWindows);
  }

  getStatus() {
    return {
      isEnabled: this.isEnabled,
      trackedWindowsCount: this.trackedWindows.size,
      config: this.config,
      hasFocusTracker: !!this.focusTracker,
      hasClickHandler: !!this.clickHandler,
      hasWindowTracker: !!this.windowTracker
    };
  }

  // Force refresh of tracked windows
  refresh() {
    logger.debug("LauncherManager: Refreshing tracked windows");
    this.trackedWindows.clear();
  }

  static async create(settings, windowsService) {
    const autoClose = settings.get_boolean(
      "launcher-auto-close-focus-loss"
    );
    if (!autoClose) return null;

    const appClass = settings.get_string("launcher-app-class") || "vicinae";

    const manager = new LauncherManager({
      appClass,
      autoCloseOnFocusLoss: autoClose,
      onWindowClosed: (windowId) => {
        windowsService.emitCloseWindow(windowId.toString());
      }
    });

    await manager.enable();
    logger.info(
      "LauncherManager: Initialized and enabled via static factory"
    );
    return manager;
  }

  static async updateOrDestroy(settings, windowsService, current) {
    const autoClose = settings.get_boolean(
      "launcher-auto-close-focus-loss"
    );

    if (autoClose && !current) {
      return LauncherManager.create(settings, windowsService);
    }

    if (!autoClose && current) {
      current.disable();
      return null;
    }

    if (autoClose && current) {
      const appClass = settings.get_string("launcher-app-class") || "vicinae";
      current.updateConfig({ appClass, autoCloseOnFocusLoss: autoClose });
    }

    return current;
  }
}

export {
  LauncherManager
};
