import { logger } from "../../utils/logger.js";
import {
  getCurrentTime,
  getWindowById,
  isMaximized
} from "../../utils/window-utils.js";
import { WorkspaceManager } from "./workspace-manager.js";


class VicinaeWindowManager {
  appClass;

  constructor(appClass) {
    this.appClass = appClass;
  }

  /**
   * Checks if the window is a target window.
   *
   * @param wmClass - The window manager class of the window.
   * @returns True if the window is a target window, false otherwise.
   */
  isTargetWindow(wmClass) {
    if (!wmClass) {
      logger.debug("isTargetWindow: No wmClass provided");
      return false;
    }

    return wmClass.toLowerCase().includes(this.appClass.toLowerCase()) || this.appClass.toLowerCase().includes(wmClass.toLowerCase());
  }

  static toWindowInfo(mw) {
    const workspace = mw.get_workspace();
    const frame = mw.get_frame_rect();
    return {
      id: mw.get_id(),
      title: mw.get_title(),
      wm_class: mw.get_wm_class() || "",
      wm_class_instance: mw.get_wm_class_instance() || "",
      pid: mw.get_pid(),
      maximized: isMaximized(mw) !== 0,
      display: mw.get_display(),
      frame_type: mw.get_frame_type(),
      window_type: mw.get_window_type(),
      layer: mw.get_layer(),
      monitor: mw.get_monitor(),
      role: mw.get_role(),
      width: frame.width,
      height: frame.height,
      x: frame.x,
      y: frame.y,
      in_current_workspace: mw.located_on_workspace?.(
        global.workspace_manager.get_active_workspace?.()
      ),
      canclose: mw.can_close(),
      canmaximize: mw.can_maximize(),
      canminimize: mw.can_minimize(),
      canshade: false,
      moveable: mw.allows_move(),
      resizeable: mw.allows_resize(),
      has_focus: mw.has_focus(),
      workspace: workspace ? workspace.index() : -1
    };
  }

  list() {
    return global.get_window_actors().map((w) => w.meta_window).filter((mw) => mw !== null).map(VicinaeWindowManager.toWindowInfo);
  }

  details(winid) {
    const mw = getWindowById(winid);
    if (!mw) throw new Error("Window not found");
    return VicinaeWindowManager.toWindowInfo(mw);
  }

  getTitle(winid) {
    const w = getWindowById(winid);
    if (w) {
      return w.get_title();
    } else {
      throw new Error("Window not found");
    }
  }

  getFrameRect(winid) {
    const w = getWindowById(winid);
    if (w) {
      const frame = w.get_frame_rect();
      return {
        x: frame.x,
        y: frame.y,
        width: frame.width,
        height: frame.height
      };
    } else {
      throw new Error("Window not found");
    }
  }

  getFrameBounds(winid) {
    const w = getWindowById(winid);
    if (w) {
      return {
        frame_bounds: w.get_frame_bounds()
      };
    } else {
      throw new Error("Window not found");
    }
  }

  moveToWorkspace(winid, workspaceNum) {
    const win = getWindowById(winid);
    if (win) {
      win.change_workspace_by_index(workspaceNum, false);
    } else {
      throw new Error("Window not found");
    }
  }

  moveResize(winid, x, y, width, height) {
    const win = getWindowById(winid);

    if (win) {
      if (win.maximized_horizontally || win.maximized_vertically) {
        win.unmaximize();
      }

      win.move_resize_frame(true, x, y, width, height);
    } else {
      throw new Error("Window not found");
    }
  }

  resize(winid, width, height) {
    const win = getWindowById(winid);
    if (win) {
      if (win.maximized_horizontally || win.maximized_vertically) {
        win.unmaximize();
      }
      const frame = win.get_frame_rect();
      win.move_resize_frame(true, frame.x, frame.y, width, height);
    } else {
      throw new Error("Window not found");
    }
  }

  move(winid, x, y) {
    const win = getWindowById(winid);
    if (win) {
      if (win.maximized_horizontally || win.maximized_vertically) {
        win.unmaximize();
      }
      win.move_frame(true, x, y);
    } else {
      throw new Error("Window not found");
    }
  }

  maximize(winid) {
    const win = getWindowById(winid);
    if (win) {
      win.maximize();
    } else {
      throw new Error("Window not found");
    }
  }

  minimize(winid) {
    const win = getWindowById(winid);
    if (win) {
      win.minimize();
    } else {
      throw new Error("Window not found");
    }
  }

  unmaximize(winid) {
    const win = getWindowById(winid);
    if (win) {
      win.unmaximize();
    } else {
      throw new Error("Window not found");
    }
  }

  unminimize(winid) {
    const win = getWindowById(winid);
    if (win) {
      win.unminimize();
    } else {
      throw new Error("Window not found");
    }
  }

  activate(winid) {
    const win = getWindowById(winid);
    if (win) {
      const currentTime = getCurrentTime();
      const workspace = win.get_workspace();
      if (workspace) {
        workspace.activate_with_focus(win, currentTime);
      } else {
        win.activate(currentTime);
      }
    } else {
      throw new Error("Window not found");
    }
  }

  close(winid) {
    const win = getWindowById(winid);
    if (win) {
      try {
        if (win.get_id() === winid) {
          win.delete(getCurrentTime());
        } else {
          throw new Error(
            "Window ID mismatch - window may be destroyed"
          );
        }
      } catch (error) {
        throw new Error(`Failed to close window ${winid}: ${error}`);
      }
    } else {
      throw new Error("Window not found");
    }
  }

  listWorkspaces() {
    return WorkspaceManager.getAllWorkspaces();
  }

  getActiveWorkspace() {
    const currentIndex = WorkspaceManager.getCurrentWorkspaceIndex();
    const workspace = WorkspaceManager.getWorkspaceInfo(currentIndex);
    if (!workspace) {
      throw new Error("No active workspace found");
    }
    return workspace;
  }
}

export {
  VicinaeWindowManager
};
