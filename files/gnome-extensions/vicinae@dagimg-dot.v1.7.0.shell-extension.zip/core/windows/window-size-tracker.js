import { logger } from "../../utils/logger.js";

class WindowSizeTracker {

  constructor(onSizeChanged) {
    this.onSizeChanged = onSizeChanged;
  }
  windowSizeSignalIds = /* @__PURE__ */ new Map();

  connectToWindow(window) {
    const windowId = window.get_id();

    if (this.windowSizeSignalIds.has(windowId)) {
      logger.debug(
        `Window ${windowId} already has a size-changed connection, skipping`
      );
      return;
    }

    try {
      const signalId = window.connect("size-changed", () => {
        try {
          this.onSizeChanged(windowId);
        } catch (error) {
          logger.debug(
            `Error in size-changed callback for window ${windowId}: ${error}`
          );
        }
      });

      this.windowSizeSignalIds.set(windowId, signalId);
    } catch (error) {
      logger.debug(
        `Failed to connect size-changed signal for window ${windowId}: ${error}`
      );
    }
  }

  connectToExistingWindows() {
    try {
      const windowActors = global.get_window_actors();

      for (const actor of windowActors) {
        if (actor.meta_window) {
          this.connectToWindow(actor.meta_window);
        }
      }
    } catch (error) {
      logger.debug(`Error connecting to existing windows: ${error}`);
    }
  }

  removeWindow(windowId) {
    this.windowSizeSignalIds.delete(windowId);
  }

  disconnectAll() {
    const windowMap = /* @__PURE__ */ new Map();
    for (const actor of global.get_window_actors()) {
      const mw = actor.meta_window;
      if (mw) windowMap.set(mw.get_id(), mw);
    }

    for (const [windowId, sizeSignalId] of this.windowSizeSignalIds) {
      try {
        const mw = windowMap.get(windowId);
        if (mw && sizeSignalId) mw.disconnect(sizeSignalId);
      } catch (error) {
        logger.debug(
          `Error disconnecting size signal for window ${windowId}: ${error}`
        );
      }
    }

    this.windowSizeSignalIds.clear();
  }
}

export {
  WindowSizeTracker
};
