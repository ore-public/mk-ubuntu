import { logger } from "./logger.js";

class SignalRegistry {
  disconnectFns = [];

  add(fn) {
    this.disconnectFns.push(fn);
  }

  disconnectAll() {
    for (const fn of this.disconnectFns) {
      try {
        fn();
      } catch (error) {
        logger.debug(`Error during signal cleanup: ${error}`);
      }
    }
    this.disconnectFns = [];
  }
}

export {
  SignalRegistry
};
