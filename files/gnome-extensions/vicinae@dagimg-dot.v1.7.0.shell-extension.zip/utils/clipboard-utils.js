import { getFocusedWindowApp } from "./window-utils.js";

const CLIPBOARD_CONFIG = {
  MAX_CLIPBOARD_SIZE: 10 * 1024 * 1024,
  // 10MB - reasonable clipboard limit
  FILE_URI_PREFIX: "file://"
};

function bufferLikeToUint8Array(buffer) {
  if (buffer instanceof Uint8Array) {
    return buffer;
  }

  if (buffer instanceof ArrayBuffer) {
    return new Uint8Array(buffer);
  }

  if (buffer && typeof buffer === "object" && "length" in buffer) {
    const uint8Array = new Uint8Array(buffer.length);
    for (let i = 0; i < buffer.length; i++) {
      uint8Array[i] = buffer[i];
    }
    return uint8Array;
  }

  throw new Error(`Unsupported buffer type: ${typeof buffer}`);
}

function decodeClipboardBytes(content) {
  if (!content || typeof content !== "object") return null;

  const obj = content;
  const ctor = obj.constructor;
  const isBytes = ctor?.name === "GLib.Bytes" || ctor?.name && String(ctor.name).includes("Bytes");

  if (isBytes) {
    const bytes = content;
    const data = typeof bytes.get_data === "function" ? bytes.get_data() : typeof bytes.toArray === "function" ? bytes.toArray() : null;
    if (data)
      return data instanceof Uint8Array ? data : new Uint8Array(data);
  }

  if ("data" in obj && obj.data) {
    const arr = obj.data;
    return arr instanceof Uint8Array ? arr : new Uint8Array(arr);
  }
  return null;
}

function isFileUri(content) {
  if (!content || typeof content !== "string") return false;
  const trimmed = content.trim();
  if (!trimmed) return false;
  return trimmed.split(/\r?\n/).every(
    (line) => line.trim().startsWith(CLIPBOARD_CONFIG.FILE_URI_PREFIX)
  );
}

function parseFileUris(content) {
  if (!content || typeof content !== "string") return [];
  return content.split(/\r?\n/).map((line) => line.trim()).filter(
    (line) => line && !line.startsWith("#") && line.startsWith(CLIPBOARD_CONFIG.FILE_URI_PREFIX)
  );
}

function toUriListFormat(uris) {
  const filtered = uris.filter(
    (u) => u?.startsWith(CLIPBOARD_CONFIG.FILE_URI_PREFIX)
  );
  if (filtered.length === 0) return new Uint8Array(0);
  const text = filtered.join("\n");
  return new TextEncoder().encode(text);
}

function calculateClipboardMetadata(event) {
  const content = event.content;
  let mimeType = "text/plain";
  const sourceApp = getFocusedWindowApp();

  if (event.source === "image") {
    if (content.startsWith("data:image/")) {
      const match = content.match(/^data:(image\/[^;]+);/);
      mimeType = match ? match[1] : "image/png";
    }
  } else if (content.startsWith("data:")) {
    const match = content.match(/^data:([^;]+);/);
    mimeType = match ? match[1] : "application/octet-stream";
  } else if (isFileUri(content)) {
    mimeType = "text/uri-list";
  } else {
    mimeType = "text/plain";

    if (content.includes("<") && content.includes(">") && (content.includes("<html") || content.includes("<div") || content.includes("<p"))) {
      mimeType = "text/html";
    }
  }

  return {
    mimeType,
    sourceApp
  };
}

export {
  CLIPBOARD_CONFIG,
  bufferLikeToUint8Array,
  calculateClipboardMetadata,
  decodeClipboardBytes,
  isFileUri,
  parseFileUris,
  toUriListFormat
};
